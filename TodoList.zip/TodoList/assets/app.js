fetch('https://jsonplaceholder.typicode.com/todos')
  .then(res=> res.json())
  .then(res =>{
      console.log(res)

  let table = document.createElement('table');
            table.classList.add('table')
            let thead = document.createElement('thead');
            let tbody = document.createElement('tbody');
            let row1 = document.createElement('tr');
            let heading1 = document.createElement('th');
            heading1.innerHTML = "USER ID";
            let heading2 = document.createElement('th');
            heading2.innerHTML = "TITLE";
            let heading3 = document.createElement('th');
            heading3.innerHTML = "COMPLETED";
            heading1.classList.add("blu")
            heading2.classList.add("blu")
            heading3.classList.add("blu")


            row1.append(heading1,heading2,heading3);
            thead.append(row1);



        res.forEach(tasks => {
            
            
            let row2 = document.createElement('tr');
            let row2Data1 = document.createElement('td');
            row2Data1.innerHTML = tasks.id;
            let row2Data2 = document.createElement('td');
            row2Data2.innerHTML = tasks.title;
            let row2Data3 = document.createElement('td');
            row2Data3.innerHTML = tasks.completed;
            //console.log(tasks.id)
         
            row2.append(row2Data1,row2Data2,row2Data3);
            tbody.append(row2);

            table.append(thead,tbody);
            row1.append(heading1);
            row1.append(heading2);
            row1.append(heading3);
            thead.append(row1);

           
        });
      
      
        console.log(tbody)
        table.append(thead,tbody);
        document.querySelector('#tabella').append(table);
       // table.style.backgroundColor = "grey"
        let totalPages = 201;
        let pageSize = 11;
        
      
        
        
     let righe =  table.getElementsByTagName("tr") 

        for(let i=1; i< totalPages; i++){
          
        let colonne = righe[i].getElementsByTagName('td')[0]
       
        if(colonne){
          txt = colonne.textContent || colonne.innerText;
       // console.log(txt)
        if(txt < pageSize){
          righe[i].style.display = ''
        }else{
          righe[i].style.display = 'none'
        }
      }

     

     
       }
      
      

      

        let select = document.getElementById('seleziona');
        
        res.forEach(user=>{
         // const array = []
          let option = document.createElement('option')
          option.innerHTML = user.userId
        //  array.push(user.userId)
          select.add(option)        
  
          })
          
        
      
        
        
        
    


        
        let tabella = document.getElementById("tabella");
        let tr = tabella.getElementsByTagName("tr");
        let filterInput = document.getElementById('myInput');
        filterInput.addEventListener('keyup', filterTitle);

        function filterTitle(){
            let filterValue = filterInput.value.toUpperCase();
           

           for (let i = 0; i < tr.length; i++) {
           let td = tr[i].getElementsByTagName('td')[1];
          
            if (td) {
             txtValue = td.textContent || td.innerText;
            
              if (txtValue.toUpperCase().indexOf(filterValue) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            }
          }
        }
        
    


        let checkInput = document.getElementById('flexSwitch');
        checkInput.addEventListener('click', filterCheck);
           
        function filterCheck(){
          for(let i = 0; i<tr.length; i++){
            const arr = [];
            let td = tr[i].getElementsByTagName('td')[2] ;
            let td2 = td || ''
         //   console.log(typeof(td2))
          
            arr.push(td2.innerHTML)
            console.log(arr)
           if(arr == 'true'){
             tr[i].style.display = ''
           }else{
             tr[i].style.display = 'none'
           }
         
          }
        }

        let back = document.getElementById('resetta')
        back.addEventListener('click', clear)
        
        function clear(){
          
            document.getElementById('myInput').value = ''
        }
        
          // select filter
       /*  let select = document.getElementById('seleziona');
          select.addEventListener('click', filterSelect);
          let opzioni = document.getElementsByTagName('option')

         function filterSelect(){
          res.forEach(el=>{
          const user = el.userId
          console.log(user)
          for(let i=0; i<opzioni.length;i++){
          
           let valore = opzioni[i].getElementByAttribute('value')
           console.log(valore)
          }
          })
          
        }  */
        
            

            
          
        
            
            
        
      
  });